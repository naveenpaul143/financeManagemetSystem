package com.finance.Service;

import com.finance.Model.AdminLogin;

public interface AdminLoginService {
	public AdminLogin findAdmin(String aname);

}
