export class Product {

    prodid:number|undefined;
    prodname:string|undefined;
    proddesc:string|undefined;
    prodimage:string|undefined;
    price:number|undefined;
    emi_3m:number|undefined;
    emi_6m:number|undefined;
    emi_9m:number|undefined;
    emi_1y:number|undefined;

    
        
  
}
