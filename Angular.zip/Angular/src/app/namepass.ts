export class Namepass {
    name: string;
  password: string;
  constructor(n:string,p:string){
   this.name=n;
   this.password=p;
  }

}
