export class Adminlogin {
    adminid: number;
    aname: string;
    apass: string;
   
}
