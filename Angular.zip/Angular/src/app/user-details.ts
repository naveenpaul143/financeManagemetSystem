export class UserDetails {
    regid:number;
    uname:string|undefined;
    phone:number|undefined;
    email:string|undefined;
    upass:string|undefined;
    address:string|undefined;
    isverified:string|undefined;
    cardtype:string|undefined;
    bankname:string|undefined;
    acc_no:string|undefined;
    ifsc_code:string|undefined;
    applied_on:Date|undefined;
 

}
