import { Carddetails } from './carddetails';

describe('Carddetails', () => {
  it('should create an instance', () => {
    expect(new Carddetails()).toBeTruthy();
  });
});
