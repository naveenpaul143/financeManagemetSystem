export class Producthistory {
    
   
    ammount_bal:number|undefined;
    amountpaid:number|undefined;
    emi:number|undefined;
    prodid:number|undefined;
    prodname:string|undefined;
    regid:number|undefined;
    price:number|undefined;
}
