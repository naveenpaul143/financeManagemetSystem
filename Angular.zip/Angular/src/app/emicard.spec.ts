import { Emicard } from './emicard';

describe('Emicard', () => {
  it('should create an instance', () => {
    expect(new Emicard()).toBeTruthy();
  });
});
