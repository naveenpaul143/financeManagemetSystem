import { Producthistory } from './producthistory';

describe('Producthistory', () => {
  it('should create an instance', () => {
    expect(new Producthistory()).toBeTruthy();
  });
});
