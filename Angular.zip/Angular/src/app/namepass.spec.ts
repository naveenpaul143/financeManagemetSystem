import { Namepass } from './namepass';

describe('Namepass', () => {
  it('should create an instance', () => {
    expect(new Namepass()).toBeTruthy();
  });
});
