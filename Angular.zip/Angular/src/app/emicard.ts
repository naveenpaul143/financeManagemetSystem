export class Emicard {
    cardtype: string;
  validity: number;
  cardlimit: number;

}
