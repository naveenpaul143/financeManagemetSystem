export class User {
    name: string;
  phoneNo: number;
  dob: Date;
  emailId: string;
  userName: string;
  password: string;
  address: string;
  //   confirmPassword: string;
  cardType: string;
  bankName: string;
  accountNo: number;
  ifscCode: string;
  
 


}
