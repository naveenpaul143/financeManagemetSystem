export class Carddetails {
    regid:number|undefined;
    cardtype:string|undefined;
    validity:Date|undefined;
    cardno:number|undefined;
    availbal:number|undefined;
    initialbal:number|undefined;
    
}

